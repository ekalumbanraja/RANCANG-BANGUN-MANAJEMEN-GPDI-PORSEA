

<?php $__env->startSection('content'); ?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assetsz/img/home/alkitab.jpg');">
      <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

        <h2>Warta Jemaat</h2>
        <ol>
          <li><a href="index.html">Home</a></li>
          <li>Warta Jemaat</li>
        </ol>

      </div>
    </div><!-- End Breadcrumbs -->
    
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        
        <div class="row gy-4 posts-list">
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-4 col-md-6">
            <div class="post-item position-relative h-100">
              <div class="post-img position-relative overflow-hidden">
                <img src="<?php echo e(asset($row->photo)); ?>" style="width: 100% ; height:15em " class="img-fluid" alt="">
                <span class="post-date"><?php echo e($row->tanggal); ?></span>
              </div>
              <div class="post-content d-flex flex-column">
                <h3 class="post-title"><?php echo e($row->judul); ?></h3>
                <p><?php echo e($row->keterangan); ?></p>
                <hr>
                <a href="#" class="moredetails"><span>Lihat lebih jelas</span><i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div><!-- End post list item -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('warta'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="assetsz/js/jquery-3.4.1.slim.min.js"></script>
<script>
  function showmore(image, title, deskripsi) {
    Swal.fire({
      title: title,
      text: deskripsi,
      imageUrl: image,
      imageWidth: 500,
      imageHeight: 400,
      imageAlt: 'Custom image',
    });
  }

  $(document).ready(function() {
    $('.moredetails').click(function(event) {
      event.preventDefault();
      var postitem = $(this).closest('.post-item');
      var image = postitem.find('img').attr('src');
      var title = postitem.find('.post-title').text();
      var deskripsi = postitem.find('p').text();

      showmore(image, title, deskripsi);
    });
  });
</script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/user/wartajemaat.blade.php ENDPATH**/ ?>