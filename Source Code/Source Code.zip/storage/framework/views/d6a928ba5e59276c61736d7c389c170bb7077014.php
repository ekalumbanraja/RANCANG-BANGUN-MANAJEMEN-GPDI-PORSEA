

<?php $__env->startPush('csss'); ?>
<link href="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assetsz/img/home/alkitab.jpg')">
        <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">
            <h2>Donasi</h2>
            <ol>
                <li><a href="/">Home</a></li>
                <li><a href="/jadwalibadahh">Donasi</a></li>
            </ol>
        </div>
    </div>
    <!-- End Breadcrumbs -->
    <br><br>
    <div class="container">
        <div class="table-responsive">
            <table class="table" id="y">
                <thead class="bg-light">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Nama Pemberi</th>
                        <th scope="col">Jenis Donasi</th>
                        <th scope="col">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?= $i ?></th>
                        <td><?php echo e($row->tanggal->format('D d M Y')); ?></td>
                        <td><?php echo e($row->nama); ?></td>
                        <td><?php echo e($row->jenis); ?></td>
                        <td><?php echo e($row->jumlah); ?></td>
                    </tr>
                    <?php $i++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('jss'); ?>
<script src="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.js"></script>

<script>
$(document).ready( function () {
    $('#y').DataTable();
} );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/user/donasi.blade.php ENDPATH**/ ?>