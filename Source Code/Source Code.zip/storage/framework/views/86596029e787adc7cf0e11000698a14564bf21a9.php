<?php $__env->startPush('jsss'); ?>
<script src="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.js"></script>
<script>
  $(document).ready( function () {
    $('#y').DataTable();
} );
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('cssss'); ?>
<link href="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.css" rel="stylesheet"/>
<style>
 table {
    width: 100%;
  }
  th,
  td {
    text-align: left;
    padding: 8px;
  }
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

  <!-- ======= Breadcrumbs ======= -->
<div class="breadcrumbs d-flex align-items-center" style="background-image: url('assetsz/img/home/alkitab.jpg')">
<div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">
<h2>Keuangan</h2>
<ol>
 <li><a href="/">Home</a></li>
 <li>Keuangan</li>

</ol>
</div>
</div>
</div><!-- End Breadcrumbs -->

  <br>
    <div class="container">
      <!-- /.card-header -->
      <div style="overflow-x: auto">
        <table class="table">
          <thead>
            <tr>
              
              <th scope="col" >Tanggal</th>
              <th scope="col">Kategori</th>
              <th scope="col">Keterangan</th>
              <th scope="col">Pemasukan</th>
              <th scope="col">Pengeluaran</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <tr>
              <td ><?php echo e($row->tanggal); ?></td>
            
            <td ><?php echo e($row->kategori); ?></td>
            <td> <p> <?php echo nl2br(e($row->keterangan)); ?></p>  
            <td>
                <?php if($row->pemasukan == 0): ?>
                    -
                <?php else: ?>
                    Rp.<?php echo e(number_format($row->pemasukan, 0, ',', '.')); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($row->pengeluaran == 0): ?>
                  -
                <?php else: ?>
                Rp.<?php echo e(number_format($row->pengeluaran,0,',','.')); ?>

                <?php endif; ?>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td>
            
            <td></td>
            <td style="text-align: right;" >TOTAL </td>
            <td>Rp.<?php echo e(number_format($pengeluaran ,0,',','.')); ?></td>
            <td> Rp.<?php echo e(number_format($pemasukan ,0,',','.')); ?></td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td></td>
            <td style="text-align: right;" >TOTAL SALDO</td>
            <td>Rp.<?php echo e(number_format($saldo ,0,',','.')); ?></td>
            
            </tr>

          </tbody>
          
        </table>
      </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>
  </div>
  
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Perkuliahan\SEM 2\Proyek Akhir\Final PA 1\Source Code\resources\views/user/keuangan.blade.php ENDPATH**/ ?>