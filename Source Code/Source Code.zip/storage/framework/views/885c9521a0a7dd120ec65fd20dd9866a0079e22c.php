

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Galery</li>
                <li class="breadcrumb-item active">Edit Galery</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

    <h1 class="text-center mt-4"style="font-family: 'Josefin Sans', sans-serif;">Edit Galery</h1>
    <div class="container">
        <form method="POST" action="/updatephoto/<?php echo e($data->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="photolama" value="<?php echo e($data->photo); ?>">
            <div class="form-group">
                <label for="nama">Judul</label>
                <input type="text" class="form-control" id="judul" name="nama"  value="<?php echo e($data->nama); ?>" >
            </div>
                

            <div class="form-group">
              <label for="photo">Photo</label>
              
              <input type="file" class="form-control" id="photo" name="photo" >
            </div>
            <div class="form-group">
            <img src="<?php echo e(asset($data->photo)); ?>" alt="" style="width:350px" height="250px">
            </div>
            
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/admin/tampilphoto.blade.php ENDPATH**/ ?>