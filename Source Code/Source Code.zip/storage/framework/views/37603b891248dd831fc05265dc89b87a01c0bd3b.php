
<?php $__env->startSection('content'); ?>       
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0"></h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Data Jemaat</li>
            <li class="breadcrumb-item active">Tambah Data</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <h1 class="text-center mb-4" style="font-family: 'Rowdies', cursive;">Data Donasi</h1>

  <div class="container">
    <div class="row">
      <div class="col-12">
        <a href="/tambahdonasi" type="button" class="btn btn-success">Tambah +</a>
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e($message); ?>

          </div>
        <?php endif; ?>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Nama Pemberi</th>
                <th scope="col">Jenis Donasi</th>
                <th scope="col">Jumlah</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $i = 1; ?>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?= $i ?></th>
                  <td><?php echo e($row->tanggal->format('D d M Y')); ?></td>
                  <td><?php echo e($row->nama); ?></td>
                  <td><?php echo e($row->jenis); ?></td>
                  <td><?php echo e($row->jumlah); ?></td>
                  <td>
                    <a href="/tampilkandonasi/<?php echo e($row->id); ?>" type="button" class="btn btn-outline-warning waves-effect">Edit</a>
                    <a href="#" class="btn btn-outline-danger waves-effect delete" nama="<?php echo e($row->nama); ?>" id="<?php echo e($row->id); ?>">Delete</a>
                  </td>
                </tr>
                <?php $i++ ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
   
<?php $__env->startPush('d'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="assets/js/jquery-3.4.1.slim.min.js"></script>
<script>
$('.delete').click(function(){
  var id = $(this).attr('id');
  var nama = $(this).attr('nama');
  Swal.fire({
    title: 'Yakin?',
    text: "Kamu akan menghapus data tersebut?",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, hapus saja!'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location="/deletedonasi/"+id+""
      Swal.fire(
        'Dihapus!',
        'Data sudah terhapus',
        'success'
      )
    }
  })
})
</script>
<?php $__env->stopPush(); ?>    

<?php $__env->startPush('ya'); ?>
<style>


tr:nth-child(even) {
  background-color: #f2f2f2;
}
</style>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/admin/donasi.blade.php ENDPATH**/ ?>