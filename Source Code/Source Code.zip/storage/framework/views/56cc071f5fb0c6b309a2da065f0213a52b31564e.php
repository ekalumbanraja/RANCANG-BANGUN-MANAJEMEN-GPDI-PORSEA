

<?php $__env->startPush('css'); ?>
<link href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assetsz/img/home/alkitab.jpg')">
        <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">
            <h2>Data Jemaat</h2>
            <ol>
                <li><a href="/">Home</a></li>
                <li>Data jemaat</li>
            </ol>
        </div>
    </div>
    </div><!-- End Breadcrumbs -->
    <br><br>

    <div class="container">
        <div class="table-responsive">
            <table class="table" id="myTable">
                <thead class="bg-light">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Tempat Lahir</th>
                        <th scope="col">Tanggal Lahir</th>
                        <th scope="col">Status Baptis</th>
                        <th scope="col">Alamat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $nomor = 1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?= $nomor?></td>
                        <td><?php echo e($row->nama); ?></td>
                        <td><?php echo e($row->jeniskelamin); ?></td>
                        <td><?php echo e($row->tempat); ?></td>
                        <td><?php echo e($row->tanggal); ?></td>
                        <td><?php echo e($row->baptis); ?></td>
                        <td><?php echo e($row->alamat); ?></td>
                    </tr>
                    <?php $nomor++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#myTable').DataTable();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/user/datajemaat.blade.php ENDPATH**/ ?>