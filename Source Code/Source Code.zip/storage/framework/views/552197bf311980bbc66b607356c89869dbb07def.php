<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin GPDI PORSEA</title>

  <link rel="icon shortcut" type="image/jpg" href="assets/img/cross.png" />
     <!-- Google Font: Source Sans Pro -->

     <link
     rel="stylesheet"
     href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"
   />
   <!-- Font Awesome Icons -->
   <link
     rel="stylesheet"
     href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>"
   />
   <!-- overlayScrollbars -->
   <link
     rel="stylesheet"
     href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>"
   />
   <!-- Theme style -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

   <link
     rel="stylesheet"
     href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>"/>
  <style>
@import  url('https://fonts.googleapis.com/css2?family=Dosis:wght@200&family=Rowdies:wght@300&family=Tilt+Prism&display=swap');

  </style>

     <?php echo $__env->yieldPushContent('keuangan.css'); ?>
     <?php echo $__env->yieldPushContent('css'); ?>
     <?php echo $__env->yieldPushContent('ya'); ?>
     <?php echo $__env->yieldPushContent('ye'); ?>
     <?php echo $__env->yieldPushContent('yu'); ?>
     <?php echo $__env->yieldPushContent('yi'); ?>




</head>

<style>
   @import  url('https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap');
    @import  url('https://fonts.googleapis.com/css2?family=Source+Code+Pro:wght@200&display=swap');
    @import  url('https://fonts.googleapis.com/css2?family=Covered+By+Your+Grace&family=Foldit&family=Kanit&family=Playfair+Display&family=Rubik+80s+Fade&family=Tilt+Prism&display=swap');
</style>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
        
        
    </ul>


    <ul class="navbar-nav ml-auto">
    
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('logout')); ?>" class="nav-link">Logout</a>
      </li>
      </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('assets/img/gereja/logo.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
  
      <div class="info">
        <a href="#" class="d-block">ADMIN GPDI</a>
      </div>
      </div>
      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="/dashboard" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
              <li class="nav-item">
                <a href="/datajemaat" class="nav-link">
                   <i class="nav-icon fas fa-table"></i>
                  <p>Data Jemaat </p>
                </a>
              </li>
          
              <li class="nav-item">
                <a href="/wartajemaat" class="nav-link">
              <i class="nav-icon fas fa-book"></i>  
                  <p>Warta Jemaat</p>
                </a>
              </li>
          

              <li class="nav-item">
                <a href="/jadwalibadah" class="nav-link">
                <i class="nav-icon fas fa-table"></i>  
                  <p>Jadwal Ibadah</p>
                </a>
              </li>
          

              <li class="nav-item">
                <a href="/keuangan" class="nav-link">
                  <i class="nav-icon fas fa-table"></i>
                    <p>Informasi Keuangan</p>
                  </a>
                </li>
          

                <li class="nav-item">
                  <a href="/donasi" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
                    <p>Data Donasi</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="/photo" class="nav-link">
                  <i class="nav-icon far fa-image"></i>

                    <p>Galeri</p>
                  </a>
                </li>
            </ul>
          </li>

        

         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

 
    <?php echo $__env->yieldContent('content'); ?>

  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2023 GPDI PORSEA.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>2023</b>
    </div>
  </footer>
</div>
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="<?php echo e(asset('admin/plugins/jquery-mousewheel/jquery.mousewheel.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/raphael/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/jquery-mapael/jquery.mapael.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/jquery-mapael/maps/usa_states.min.js')); ?>"></script>
<!-- ChartJS -->  
<script src="<?php echo e(asset('admin/plugins/chart.js/Chart.min.js')); ?>"></script>

<!-- AdminLTE for demo purposes -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('admin/dist/js/pages/dashboard2.js')); ?>"></script>
<script src="assets/js/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php echo $__env->yieldPushContent('scriptss'); ?>
<?php echo $__env->yieldPushContent('scriptsss'); ?>
<?php echo $__env->yieldPushContent('scriptssss'); ?>
<?php echo $__env->yieldPushContent('scriptsssss'); ?>
<?php echo $__env->yieldPushContent('s'); ?>
<?php echo $__env->yieldPushContent('d'); ?>
<?php echo $__env->yieldPushContent('dd'); ?>
<?php echo $__env->yieldPushContent('ddd'); ?>
<?php echo $__env->yieldPushContent('ss'); ?>
<?php echo $__env->yieldPushContent('sss'); ?>
<?php echo $__env->yieldPushContent('scriptssssss'); ?>
<?php echo $__env->yieldPushContent('script'); ?>
<?php echo $__env->yieldPushContent('photo'); ?>
<?php echo $__env->yieldPushContent('warta'); ?>

</body>
</html>

<?php /**PATH C:\Users\ekalu\Documents\GitHub\PA1-Kel16\PA1\resources\views/layout/admin2.blade.php ENDPATH**/ ?>